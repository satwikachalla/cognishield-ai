
import React, { useState, useEffect } from 'react';
import { ScreeningStep, CognitiveResult, AuthState } from './types';
import { analyzeTextAndSpeech, generateRecommendationWithMaps } from './services/geminiService';

// Sub-components
import Header from './components/Header';
import Welcome from './components/Welcome';
import MemoryEncoding from './components/MemoryEncoding';
import ReactionTest from './components/ReactionTest';
import LanguageTest from './components/LanguageTest';
import SpeechTest from './components/SpeechTest';
import MemoryRecall from './components/MemoryRecall';
import ResultsView from './components/ResultsView';
import Games from './components/Games';
import LoginPage from './components/LoginPage';

const WORDS_TO_REMEMBER = ["Apple", "River", "Train", "Compass", "Blueberry"];

const App: React.FC = () => {
  const [auth, setAuth] = useState<AuthState>({ isAuthenticated: false });
  const [step, setStep] = useState<ScreeningStep>(ScreeningStep.WELCOME);
  const [location, setLocation] = useState<{lat: number, lng: number} | null>(null);
  const [userResponse, setUserResponse] = useState({
    memoryEncoded: false,
    reactionTimes: [] as number[],
    describeDayText: "",
    audioBase64: "",
    recalledWords: [] as string[],
  });
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<CognitiveResult | null>(null);
  const [aiSummary, setAiSummary] = useState("");
  const [showGames, setShowGames] = useState(false);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => setLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
        (err) => console.warn("Geolocation access denied", err)
      );
    }
  }, []);

  const handleLogin = (name: string, email: string) => {
    setAuth({
      isAuthenticated: true,
      user: { name, email }
    });
  };

  const handleNext = () => {
    setStep((prev) => prev + 1);
  };

  const calculateResults = async () => {
    setLoading(true);
    setStep(ScreeningStep.PROCESSING);

    const correctCount = userResponse.recalledWords.filter(w => 
      WORDS_TO_REMEMBER.map(ow => ow.toLowerCase()).includes(w.toLowerCase())
    ).length;
    
    const recallAccuracy = (correctCount / WORDS_TO_REMEMBER.length) * 100;
    const reactionTimeAvg = userResponse.reactionTimes.length > 0 
      ? userResponse.reactionTimes.reduce((a, b) => a + b, 0) / userResponse.reactionTimes.length 
      : 800;

    const aiData = await analyzeTextAndSpeech(userResponse.describeDayText, userResponse.audioBase64);

    const memoryPart = (recallAccuracy / 100) * 40;
    const langPart = ((aiData?.vocabularyRichness || 0.5) * 30);
    const reactionPart = Math.max(0, (1 - (reactionTimeAvg / 1500)) * 30);
    
    const rawHealthScore = memoryPart + langPart + reactionPart;
    const riskScore = 100 - rawHealthScore;

    let category: 'Low Risk' | 'Mild Risk' | 'Elevated Risk' = 'Low Risk';
    if (riskScore > 40) category = 'Elevated Risk';
    else if (riskScore > 20) category = 'Mild Risk';

    const finalResult: CognitiveResult = {
      memoryScore: rawHealthScore,
      recallAccuracy,
      reactionTimeAvg,
      languageAnalysis: {
        sentenceLength: aiData?.sentenceLength || 0,
        vocabularyRichness: aiData?.vocabularyRichness || 0,
        wordRepetition: aiData?.wordRepetition || 0,
        coherence: aiData?.coherence || "Pending analysis",
      },
      speechAnalysis: aiData?.transcript ? {
        fluency: aiData.fluency,
        hesitationLevel: aiData.hesitationLevel,
        sentiment: aiData.sentiment,
        transcript: aiData.transcript,
        accuracyScore: aiData.accuracyScore
      } : undefined,
      totalRiskScore: Math.round(riskScore),
      riskCategory: category,
      timestamp: new Date().toISOString(),
    };

    const mapsRec = await generateRecommendationWithMaps(finalResult, location?.lat, location?.lng);
    finalResult.nearbyDoctors = mapsRec.links;
    
    setResults(finalResult);
    setAiSummary(mapsRec.text || "Analysis complete.");
    setLoading(false);
    setStep(ScreeningStep.RESULTS);
  };

  if (!auth.isAuthenticated) {
    return <LoginPage onLogin={handleLogin} />;
  }

  if (showGames) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header onReset={() => setShowGames(false)} />
        <Games onClose={() => setShowGames(false)} />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <Header onReset={() => {
        setStep(ScreeningStep.WELCOME);
        setResults(null);
        setShowGames(false);
      }} />
      
      <main className="flex-1 container mx-auto px-4 py-8 max-w-4xl">
        <div className="mb-8 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-700 font-bold">
              {auth.user?.name.charAt(0)}
            </div>
            <div>
              <p className="text-xs text-slate-400 font-bold uppercase tracking-wider">Patient</p>
              <p className="text-sm font-bold text-slate-700">{auth.user?.name}</p>
            </div>
          </div>
          {step > 0 && step < ScreeningStep.RESULTS && (
            <div className="flex gap-1">
              {[1, 2, 3, 4, 5].map((s) => (
                <div key={s} className={`h-1.5 w-8 rounded-full transition-colors ${step >= s ? 'bg-indigo-600' : 'bg-slate-200'}`}></div>
              ))}
            </div>
          )}
        </div>

        {step === ScreeningStep.WELCOME && <Welcome onStart={handleNext} />}
        
        {step === ScreeningStep.MEMORY_ENCODING && (
          <MemoryEncoding words={WORDS_TO_REMEMBER} onComplete={handleNext} />
        )}

        {step === ScreeningStep.REACTION_TEST && (
          <ReactionTest 
            onComplete={(times) => {
              setUserResponse(prev => ({ ...prev, reactionTimes: times }));
              handleNext();
            }} 
          />
        )}

        {step === ScreeningStep.LANGUAGE_TEXT && (
          <LanguageTest 
            onComplete={(text) => {
              setUserResponse(prev => ({ ...prev, describeDayText: text }));
              handleNext();
            }} 
          />
        )}

        {step === ScreeningStep.SPEECH_AUDIO && (
          <SpeechTest 
            onComplete={(base64) => {
              setUserResponse(prev => ({ ...prev, audioBase64: base64 }));
              handleNext();
            }} 
            onSkip={handleNext}
          />
        )}

        {step === ScreeningStep.MEMORY_RECALL && (
          <MemoryRecall 
            onComplete={(words) => {
              setUserResponse(prev => ({ ...prev, recalledWords: words }));
              calculateResults();
            }} 
          />
        )}

        {step === ScreeningStep.PROCESSING && (
          <div className="flex flex-col items-center justify-center py-20 space-y-6">
            <div className="w-16 h-16 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
            <h2 className="text-2xl font-bold text-slate-800">Analyzing Cognitive Metrics...</h2>
            <p className="text-slate-500 text-center max-w-xs">Gemini AI is querying nearby medical specialists for you.</p>
          </div>
        )}

        {step === ScreeningStep.RESULTS && results && (
          <ResultsView 
            results={results} 
            aiSummary={aiSummary} 
            onOpenGames={() => setShowGames(true)}
          />
        )}
      </main>

      <footer className="py-6 border-t border-slate-200 bg-white text-center text-xs text-slate-400">
        <p>&copy; 2024 CogniShield. This tool provides screening, not medical diagnosis.</p>
      </footer>
    </div>
  );
};

export default App;
