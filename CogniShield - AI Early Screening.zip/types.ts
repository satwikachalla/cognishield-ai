
export interface GroundingLink {
  title: string;
  uri: string;
  phone?: string;
}

export interface CognitiveResult {
  memoryScore: number;
  recallAccuracy: number;
  reactionTimeAvg: number;
  languageAnalysis: {
    sentenceLength: number;
    vocabularyRichness: number;
    wordRepetition: number;
    coherence: string;
  };
  speechAnalysis?: {
    fluency: string;
    hesitationLevel: string;
    sentiment: string;
    transcript: string;
    accuracyScore: number;
  };
  totalRiskScore: number;
  riskCategory: 'Low Risk' | 'Mild Risk' | 'Elevated Risk';
  timestamp: string;
  nearbyDoctors?: GroundingLink[];
}

export enum ScreeningStep {
  WELCOME,
  MEMORY_ENCODING,
  REACTION_TEST,
  LANGUAGE_TEXT,
  SPEECH_AUDIO,
  MEMORY_RECALL,
  PROCESSING,
  RESULTS
}

export interface AuthState {
  isAuthenticated: boolean;
  user?: {
    name: string;
    email: string;
  };
}
