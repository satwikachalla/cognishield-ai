
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });

export const analyzeTextAndSpeech = async (
  text: string, 
  audioBase64?: string
) => {
  const parts: any[] = [{ text: `You are a clinical linguistic analyst. Analyze the following inputs for cognitive screening markers.
    
    TEXT INPUT: "${text}"
    EXPECTED SPEECH PHRASE: "Today is a beautiful day and I am feeling focused."
    
    TASKS:
    1. Evaluate text for: average sentence length, vocabulary richness (0-1), word repetition (0-1), and coherence.
    2. If audio is provided, analyze the recording for:
       - Fluency: Rate of speech and rhythmic patterns.
       - Hesitation: Frequency of pauses or "um/uh" sounds.
       - Transcription: Transcribe what the user said.
       - Sentiment: General mood detected in the voice.
       - Accuracy: Score (0-100) how closely they followed the expected phrase.
    
    Return the analysis strictly as a JSON object.` 
  }];

  if (audioBase64) {
    parts.push({
      inlineData: {
        mimeType: 'audio/webm',
        data: audioBase64
      }
    });
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: { parts },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            sentenceLength: { type: Type.NUMBER },
            vocabularyRichness: { type: Type.NUMBER },
            wordRepetition: { type: Type.NUMBER },
            coherence: { type: Type.STRING },
            fluency: { type: Type.STRING },
            hesitationLevel: { type: Type.STRING, description: "Low, Medium, or High" },
            sentiment: { type: Type.STRING },
            transcript: { type: Type.STRING },
            accuracyScore: { type: Type.NUMBER }
          },
          required: ["sentenceLength", "vocabularyRichness", "wordRepetition", "coherence"]
        }
      }
    });

    return JSON.parse(response.text || '{}');
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    return null;
  }
};

export const generateRecommendationWithMaps = async (
  result: any, 
  lat?: number, 
  lng?: number
) => {
  const prompt = `Based on these cognitive screening results:
    Risk Score: ${result.totalRiskScore}/100
    Category: ${result.riskCategory}
    Memory Recall: ${result.recallAccuracy}%
    Reaction Time: ${result.reactionTimeAvg}ms
    
    Provide a professional but friendly summary of these findings and specific recommendations.
    Additionally, find and list at least 3 nearby Neurologists or Memory Assessment Clinics.
    FOR EACH CLINIC, YOU MUST PROVIDE THEIR CONTACT PHONE NUMBER. 
    Format your recommendation text to include the phone numbers clearly next to each clinic name.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-lite-latest',
      contents: prompt,
      config: {
        tools: [{ googleMaps: {} }],
        toolConfig: lat && lng ? {
          retrievalConfig: {
            latLng: { latitude: lat, longitude: lng }
          }
        } : undefined
      }
    });

    const aiText = response.text || "";
    const links: { title: string, uri: string, phone?: string }[] = [];
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    
    // Extract basic chunks
    if (chunks) {
      chunks.forEach((chunk: any) => {
        if (chunk.maps) {
          const title = chunk.maps.title || "Nearby Specialist";
          // Attempt to find a phone number near this title in the text using regex
          const phoneRegex = /(?:\+?(\d{1,3}))?[-. (]*(\d{3})[-. )]*(\d{3})[-. ]*(\d{4})(?: *x(\d+))?/;
          const match = aiText.match(new RegExp(`${title}.*?(${phoneRegex.source})`, 's')) || aiText.match(phoneRegex);
          
          links.push({
            title: title,
            uri: chunk.maps.uri,
            phone: match ? match[1] || match[0] : undefined
          });
        }
      });
    }

    return {
      text: aiText,
      links
    };
  } catch (error) {
    console.error("Maps Recommendation Error:", error);
    return { text: "Unable to generate specific recommendations.", links: [] };
  }
};
