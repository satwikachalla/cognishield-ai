
import React, { useState, useEffect, useCallback } from 'react';

interface Props {
  onClose: () => void;
}

type GameType = 'MENU' | 'MEMORY' | 'STROOP' | 'MATH';

const Games: React.FC<Props> = ({ onClose }) => {
  const [activeGame, setActiveGame] = useState<GameType>('MENU');

  if (activeGame === 'MENU') {
    return (
      <div className="flex-1 container mx-auto px-4 py-10 max-w-4xl animate-in fade-in duration-500">
        <div className="flex justify-between items-center mb-10">
          <div>
            <h2 className="text-3xl font-extrabold text-slate-900">Brain Training Suite</h2>
            <p className="text-slate-500">Select an activity to strengthen cognitive pathways.</p>
          </div>
          <button 
            onClick={onClose}
            className="px-4 py-2 text-sm font-bold text-slate-400 hover:text-slate-600 border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors"
          >
            RETURN TO RESULTS
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <GameCard 
            title="Memory Matrix" 
            desc="Visual-spatial pattern recall. Boosts short-term memory." 
            icon="🧩" 
            color="bg-emerald-50 text-emerald-600"
            onClick={() => setActiveGame('MEMORY')}
          />
          <GameCard 
            title="Stroop Focus" 
            desc="Inhibitory control test. Improves attention and focus." 
            icon="🎨" 
            color="bg-amber-50 text-amber-600"
            onClick={() => setActiveGame('STROOP')}
          />
          <GameCard 
            title="Speed Math" 
            desc="Rapid arithmetic processing. Sharpens executive function." 
            icon="🔢" 
            color="bg-indigo-50 text-indigo-600"
            onClick={() => setActiveGame('MATH')}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 container mx-auto px-4 py-10 max-w-2xl flex flex-col items-center animate-in zoom-in-95 duration-300">
      <div className="w-full flex justify-between items-center mb-8">
        <button onClick={() => setActiveGame('MENU')} className="text-indigo-600 font-bold flex items-center gap-2 hover:translate-x-1 transition-transform">
          ← BACK TO MENU
        </button>
        <span className="text-xs font-black text-slate-300 uppercase tracking-widest">
          {activeGame.replace('_', ' ')}
        </span>
      </div>

      {activeGame === 'MEMORY' && <MemoryMatrixGame />}
      {activeGame === 'STROOP' && <StroopGame />}
      {activeGame === 'MATH' && <SpeedMathGame />}
    </div>
  );
};

const GameCard = ({ title, desc, icon, color, onClick }: any) => (
  <button 
    onClick={onClick}
    className="p-8 bg-white rounded-3xl shadow-sm border border-slate-100 text-left hover:shadow-xl hover:-translate-y-1 transition-all group"
  >
    <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-3xl mb-6 ${color}`}>
      {icon}
    </div>
    <h3 className="text-xl font-bold text-slate-800 mb-2 group-hover:text-indigo-600 transition-colors">{title}</h3>
    <p className="text-slate-500 text-sm leading-relaxed">{desc}</p>
  </button>
);

// --- Sub Game: Memory Matrix ---
const MemoryMatrixGame = () => {
  const [sequence, setSequence] = useState<number[]>([]);
  const [userSequence, setUserSequence] = useState<number[]>([]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [activeButton, setActiveButton] = useState<number | null>(null);
  const [score, setScore] = useState(0);

  const playSequence = async (seq: number[]) => {
    setIsPlaying(true);
    setUserSequence([]);
    for (const id of seq) {
      await new Promise(r => setTimeout(r, 600));
      setActiveButton(id);
      await new Promise(r => setTimeout(r, 400));
      setActiveButton(null);
    }
    setIsPlaying(false);
  };

  const startNewGame = () => {
    setScore(0);
    const newSeq = [Math.floor(Math.random() * 4)];
    setSequence(newSeq);
    playSequence(newSeq);
  };

  const handleButtonClick = (id: number) => {
    if (isPlaying) return;
    setActiveButton(id);
    setTimeout(() => setActiveButton(null), 100);

    const nextUserSeq = [...userSequence, id];
    setUserSequence(nextUserSeq);

    if (id !== sequence[userSequence.length]) {
      alert(`Game Over! Score: ${score}`);
      setSequence([]);
      return;
    }

    if (nextUserSeq.length === sequence.length) {
      setScore(s => s + 1);
      const nextSeq = [...sequence, Math.floor(Math.random() * 4)];
      setSequence(nextSeq);
      setTimeout(() => playSequence(nextSeq), 1000);
    }
  };

  return (
    <div className="w-full flex flex-col items-center">
      <ScoreDisplay score={score} />
      <div className="grid grid-cols-2 gap-4 w-full max-w-sm aspect-square">
        {[0, 1, 2, 3].map(id => (
          <button
            key={id}
            onClick={() => handleButtonClick(id)}
            disabled={isPlaying || sequence.length === 0}
            className={`rounded-3xl shadow-lg border-b-8 active:border-b-0 active:translate-y-2 transition-all duration-100 ${
              id === 0 ? 'bg-emerald-400 border-emerald-600' :
              id === 1 ? 'bg-amber-400 border-amber-600' :
              id === 2 ? 'bg-rose-400 border-rose-600' :
              'bg-sky-400 border-sky-600'
            } ${activeButton === id ? 'brightness-125 scale-105' : 'brightness-100'}`}
          />
        ))}
      </div>
      {sequence.length === 0 && <StartBtn onClick={startNewGame} />}
    </div>
  );
};

// --- Sub Game: Stroop Focus ---
const COLORS = [
  { name: 'RED', value: '#ef4444' },
  { name: 'BLUE', value: '#3b82f6' },
  { name: 'GREEN', value: '#22c55e' },
  { name: 'YELLOW', value: '#eab308' }
];

const StroopGame = () => {
  const [score, setScore] = useState(0);
  const [current, setCurrent] = useState<{ text: string, color: string } | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);

  const nextRound = useCallback(() => {
    const textIdx = Math.floor(Math.random() * COLORS.length);
    const colorIdx = Math.floor(Math.random() * COLORS.length);
    setCurrent({ text: COLORS[textIdx].name, color: COLORS[colorIdx].value });
  }, []);

  const handleChoice = (colorValue: string) => {
    if (!current) return;
    if (colorValue === current.color) {
      setScore(s => s + 1);
      nextRound();
    } else {
      alert(`Wrong choice! Score: ${score}`);
      setIsPlaying(false);
      setCurrent(null);
    }
  };

  return (
    <div className="w-full flex flex-col items-center space-y-12">
      <ScoreDisplay score={score} />
      {current ? (
        <div className="flex flex-col items-center space-y-12 w-full">
          <div className="text-6xl font-black py-10 px-16 bg-white rounded-3xl border border-slate-100 shadow-sm transition-all" style={{ color: current.color }}>
            {current.text}
          </div>
          <p className="text-slate-400 text-sm font-bold uppercase">Tap the color of the text, not the word!</p>
          <div className="grid grid-cols-2 gap-4 w-full">
            {COLORS.map(c => (
              <button 
                key={c.name}
                onClick={() => handleChoice(c.value)}
                className="h-20 rounded-2xl border-b-4 shadow-md transition-all active:translate-y-1 active:border-b-0"
                style={{ backgroundColor: c.value, borderColor: 'rgba(0,0,0,0.1)' }}
              />
            ))}
          </div>
        </div>
      ) : (
        <StartBtn onClick={() => { setIsPlaying(true); setScore(0); nextRound(); }} />
      )}
    </div>
  );
};

// --- Sub Game: Speed Math ---
const SpeedMathGame = () => {
  const [score, setScore] = useState(0);
  const [problem, setProblem] = useState<{ q: string, a: number, options: number[] } | null>(null);
  const [timeLeft, setTimeLeft] = useState(5);

  const generateProblem = useCallback(() => {
    const a = Math.floor(Math.random() * 20) + 1;
    const b = Math.floor(Math.random() * 20) + 1;
    const ans = a + b;
    const options = [ans, ans + 2, ans - 1, ans + 5].sort(() => Math.random() - 0.5);
    setProblem({ q: `${a} + ${b}`, a: ans, options });
    setTimeLeft(5);
  }, []);

  useEffect(() => {
    if (!problem) return;
    const timer = setInterval(() => {
      setTimeLeft(t => {
        if (t <= 1) {
          alert(`Time's up! Score: ${score}`);
          setProblem(null);
          return 0;
        }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [problem, score]);

  const handleAnswer = (val: number) => {
    if (val === problem?.a) {
      setScore(s => s + 1);
      generateProblem();
    } else {
      alert(`Wrong! Score: ${score}`);
      setProblem(null);
    }
  };

  return (
    <div className="w-full flex flex-col items-center space-y-8">
      <div className="flex justify-between w-full items-center">
        <ScoreDisplay score={score} />
        {problem && (
          <div className="text-right">
             <span className={`text-4xl font-black ${timeLeft < 3 ? 'text-red-500 animate-pulse' : 'text-slate-800'}`}>{timeLeft}s</span>
             <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Time Left</p>
          </div>
        )}
      </div>
      
      {problem ? (
        <div className="w-full flex flex-col items-center space-y-10">
          <div className="text-7xl font-black text-slate-800 bg-white p-12 rounded-[2.5rem] shadow-sm border border-slate-100">
            {problem.q}
          </div>
          <div className="grid grid-cols-2 gap-4 w-full">
            {problem.options.map(opt => (
              <button 
                key={opt}
                onClick={() => handleAnswer(opt)}
                className="py-6 bg-white border border-slate-200 rounded-2xl text-2xl font-black text-slate-700 hover:bg-indigo-50 hover:border-indigo-200 transition-all"
              >
                {opt}
              </button>
            ))}
          </div>
        </div>
      ) : (
        <StartBtn onClick={() => { setScore(0); generateProblem(); }} />
      )}
    </div>
  );
};

const ScoreDisplay = ({ score }: { score: number }) => (
  <div className="mb-6 text-center">
    <span className="text-6xl font-black text-indigo-600">{score}</span>
    <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-2">Score</p>
  </div>
);

const StartBtn = ({ onClick }: { onClick: () => void }) => (
  <button 
    onClick={onClick}
    className="mt-12 bg-indigo-600 text-white px-10 py-4 rounded-2xl font-bold text-xl hover:bg-indigo-700 shadow-xl transform transition-transform hover:scale-105 active:scale-95"
  >
    START ACTIVITY
  </button>
);

export default Games;
