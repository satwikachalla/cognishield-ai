
import React, { useState } from 'react';

interface Props {
  onComplete: (text: string) => void;
}

const LanguageTest: React.FC<Props> = ({ onComplete }) => {
  const [text, setText] = useState("");

  const wordCount = text.trim() === "" ? 0 : text.trim().split(/\s+/).length;

  return (
    <div className="max-w-2xl mx-auto bg-white p-8 rounded-3xl shadow-sm border border-slate-100 space-y-6 animate-in fade-in duration-500">
      <div className="space-y-2">
        <h2 className="text-2xl font-bold text-slate-800">Step 3: Real-Time Language Analysis</h2>
        <p className="text-slate-500">
          Describe your morning or what you have planned for the rest of the day in 3-5 complete sentences.
        </p>
      </div>

      <div className="relative">
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="I woke up around 7am and had a cup of coffee..."
          className="w-full h-48 p-4 rounded-xl border-2 border-slate-100 focus:border-indigo-500 outline-none resize-none transition-colors text-slate-700 leading-relaxed"
        />
        <div className="absolute bottom-4 right-4 text-xs font-bold text-slate-400 bg-slate-50 px-2 py-1 rounded">
          {wordCount} words
        </div>
      </div>

      <button
        disabled={wordCount < 15}
        onClick={() => onComplete(text)}
        className={`w-full py-4 rounded-xl font-bold transition-all ${
          wordCount >= 15 
          ? 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-lg shadow-indigo-100' 
          : 'bg-slate-100 text-slate-400 cursor-not-allowed'
        }`}
      >
        {wordCount < 15 ? `Write at least ${15 - wordCount} more words` : 'Continue to Speech Test'}
      </button>
    </div>
  );
};

export default LanguageTest;
