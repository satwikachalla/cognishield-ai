
import React, { useState, useRef, useEffect } from 'react';

interface Props {
  onComplete: (base64: string) => void;
  onSkip: () => void;
}

const SpeechTest: React.FC<Props> = ({ onComplete, onSkip }) => {
  const [isRecording, setIsRecording] = useState(false);
  const [recorded, setRecorded] = useState(false);
  const [timer, setTimer] = useState(0);
  const mediaRecorder = useRef<MediaRecorder | null>(null);
  const chunks = useRef<Blob[]>([]);
  const timerInterval = useRef<number | null>(null);

  useEffect(() => {
    if (isRecording) {
      timerInterval.current = window.setInterval(() => {
        setTimer(t => t + 1);
      }, 1000);
    } else {
      if (timerInterval.current) clearInterval(timerInterval.current);
      setTimer(0);
    }
    return () => { if (timerInterval.current) clearInterval(timerInterval.current); };
  }, [isRecording]);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaRecorder.current = new MediaRecorder(stream);
      chunks.current = [];

      mediaRecorder.current.ondataavailable = (e) => {
        if (e.data.size > 0) chunks.current.push(e.data);
      };

      mediaRecorder.current.onstop = () => {
        const blob = new Blob(chunks.current, { type: 'audio/webm' });
        const reader = new FileReader();
        reader.readAsDataURL(blob);
        reader.onloadend = () => {
          const base64String = (reader.result as string).split(',')[1];
          onComplete(base64String);
        };
        setRecorded(true);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.current.start();
      setIsRecording(true);
      setTimeout(() => {
        if (mediaRecorder.current?.state === "recording") stopRecording();
      }, 10000);
    } catch (err) {
      console.error("Microphone access denied", err);
      alert("Microphone access is required for speech analysis.");
    }
  };

  const stopRecording = () => {
    mediaRecorder.current?.stop();
    setIsRecording(false);
  };

  return (
    <div className="max-w-xl mx-auto bg-white p-8 rounded-3xl shadow-sm border border-slate-100 text-center space-y-6 animate-in fade-in duration-500">
      <div className="space-y-2">
        <h2 className="text-2xl font-bold text-slate-800">Step 4: Voice Biomarkers</h2>
        <p className="text-slate-500">
          Our AI analyzes hesitations, tone, and speech clarity.
        </p>
      </div>

      <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 italic text-slate-700">
        "Today is a beautiful day and I am feeling focused."
      </div>

      <div className="py-8 flex flex-col items-center justify-center space-y-6">
        {isRecording ? (
          <div className="flex flex-col items-center">
            <div className="flex gap-1 h-12 items-center mb-6">
              {[...Array(8)].map((_, i) => (
                <div 
                  key={i} 
                  className="w-1.5 bg-indigo-500 rounded-full animate-bounce" 
                  style={{ 
                    height: `${20 + Math.random() * 80}%`,
                    animationDelay: `${i * 100}ms`,
                    animationDuration: '0.6s'
                  }}
                ></div>
              ))}
            </div>
            <button 
              onClick={stopRecording}
              className="w-20 h-20 bg-red-600 rounded-full flex items-center justify-center text-white shadow-xl hover:scale-105 active:scale-95 transition-all"
            >
              <div className="w-6 h-6 bg-white rounded-sm"></div>
            </button>
            <p className="mt-4 text-red-600 font-bold tracking-widest text-xs uppercase animate-pulse">
              Recording 0:0{timer}
            </p>
          </div>
        ) : (
          <button 
            disabled={recorded}
            onClick={startRecording}
            className={`w-20 h-20 rounded-full flex items-center justify-center text-white shadow-xl transition-all hover:scale-105 active:scale-95 ${recorded ? 'bg-slate-300' : 'bg-indigo-600'}`}
          >
            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z"></path>
            </svg>
          </button>
        )}
        {!isRecording && !recorded && <p className="text-xs font-bold text-slate-400 uppercase">Tap to record</p>}
        {recorded && <p className="text-green-600 font-bold text-xs uppercase">Analysis Pending...</p>}
      </div>

      <div className="pt-4 border-t border-slate-50">
        <button 
          onClick={onSkip}
          className="text-slate-400 text-xs font-bold hover:text-indigo-600 transition-colors uppercase tracking-widest"
        >
          Skip This Step
        </button>
      </div>
    </div>
  );
};

export default SpeechTest;
