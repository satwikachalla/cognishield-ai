
import React from 'react';

interface WelcomeProps {
  onStart: () => void;
}

const Welcome: React.FC<WelcomeProps> = ({ onStart }) => {
  return (
    <div className="animate-in fade-in duration-700 text-center space-y-8 py-10">
      <div className="space-y-4">
        <h1 className="text-4xl md:text-5xl font-extrabold text-slate-900 tracking-tight">
          AI-Based Early Cognitive Screening
        </h1>
        <p className="text-xl text-slate-600 max-w-2xl mx-auto">
          A proactive way to monitor brain health. Our AI evaluates memory, reaction time, and linguistic patterns to provide a personalized cognitive risk profile.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
        {[
          { 
            title: "Memory Testing", 
            desc: "Brief recall exercises to test short-term retention.",
            icon: "🧠" 
          },
          { 
            title: "Speech & Text Analysis", 
            desc: "AI detects linguistic markers often associated with early cognitive shifts.",
            icon: "🗣️" 
          },
          { 
            title: "Reaction Speed", 
            desc: "Measuring neurological response through pattern recognition.",
            icon: "⚡" 
          },
        ].map((item, i) => (
          <div key={i} className="p-6 bg-white rounded-2xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow">
            <div className="text-3xl mb-3">{item.icon}</div>
            <h3 className="text-lg font-bold text-slate-800 mb-2">{item.title}</h3>
            <p className="text-slate-500 text-sm leading-relaxed">{item.desc}</p>
          </div>
        ))}
      </div>

      <div className="pt-6">
        <button 
          onClick={onStart}
          className="bg-indigo-600 text-white px-8 py-4 rounded-xl font-bold text-lg hover:bg-indigo-700 hover:scale-[1.02] active:scale-95 transition-all shadow-lg shadow-indigo-200"
        >
          Start 5-Minute Screening
        </button>
        <p className="mt-4 text-xs text-slate-400">
          Takes approximately 5-7 minutes. Please ensure you are in a quiet environment.
        </p>
      </div>
    </div>
  );
};

export default Welcome;
