
import React, { useState, useEffect } from 'react';

interface Props {
  words: string[];
  onComplete: () => void;
}

const MemoryEncoding: React.FC<Props> = ({ words, onComplete }) => {
  const [timeLeft, setTimeLeft] = useState(15);

  useEffect(() => {
    if (timeLeft <= 0) {
      onComplete();
      return;
    }
    const timer = setInterval(() => setTimeLeft(t => t - 1), 1000);
    return () => clearInterval(timer);
  }, [timeLeft, onComplete]);

  return (
    <div className="max-w-xl mx-auto bg-white p-8 rounded-3xl shadow-sm border border-slate-100 text-center space-y-8 animate-in slide-in-from-bottom-4 duration-500">
      <div className="space-y-2">
        <h2 className="text-2xl font-bold text-slate-800">Step 1: Memory Encoding</h2>
        <p className="text-slate-500">Please memorize these 5 words. You will be asked to recall them later.</p>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {words.map((word, i) => (
          <div key={i} className="text-3xl font-bold text-indigo-600 bg-indigo-50 py-4 rounded-xl border border-indigo-100 uppercase tracking-widest animate-in zoom-in-95" style={{ animationDelay: `${i * 100}ms` }}>
            {word}
          </div>
        ))}
      </div>

      <div className="pt-4">
        <div className="text-sm font-semibold text-slate-400 mb-2 uppercase">Time Remaining</div>
        <div className="text-4xl font-mono font-bold text-indigo-600">{timeLeft}s</div>
      </div>
    </div>
  );
};

export default MemoryEncoding;
