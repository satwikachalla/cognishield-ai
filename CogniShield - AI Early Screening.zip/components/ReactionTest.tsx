
import React, { useState, useEffect, useRef } from 'react';

interface Props {
  onComplete: (times: number[]) => void;
}

const ReactionTest: React.FC<Props> = ({ onComplete }) => {
  const [stage, setStage] = useState<'waiting' | 'ready' | 'result'>('waiting');
  const [times, setTimes] = useState<number[]>([]);
  const startTime = useRef<number>(0);
  const timeoutRef = useRef<number | null>(null);

  const startRound = () => {
    setStage('waiting');
    const delay = Math.random() * 2000 + 1000;
    timeoutRef.current = window.setTimeout(() => {
      setStage('ready');
      startTime.current = performance.now();
    }, delay);
  };

  useEffect(() => {
    startRound();
    return () => { if (timeoutRef.current) clearTimeout(timeoutRef.current); };
  }, []);

  const handleClick = () => {
    if (stage === 'waiting') {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      alert("Too early! Round restarted.");
      startRound();
      return;
    }
    if (stage === 'ready') {
      const reaction = performance.now() - startTime.current;
      const newTimes = [...times, reaction];
      setTimes(newTimes);
      setStage('result');
      
      if (newTimes.length >= 3) {
        setTimeout(() => onComplete(newTimes), 1500);
      } else {
        setTimeout(startRound, 1000);
      }
    }
  };

  return (
    <div className="max-w-xl mx-auto space-y-8 animate-in fade-in duration-500">
      <div className="text-center space-y-2">
        <h2 className="text-2xl font-bold text-slate-800">Step 2: Reaction Speed</h2>
        <p className="text-slate-500">Click the box below as fast as you can when it turns <b>GREEN</b>.</p>
        <p className="text-sm text-indigo-600 font-medium">Progress: {times.length}/3</p>
      </div>

      <div 
        onClick={handleClick}
        className={`h-64 rounded-3xl cursor-pointer flex items-center justify-center text-white font-bold text-2xl shadow-inner transition-colors duration-200 ${
          stage === 'waiting' ? 'bg-red-400' : 
          stage === 'ready' ? 'bg-green-500 shadow-[0_0_30px_rgba(34,197,94,0.4)]' : 
          'bg-indigo-500'
        }`}
      >
        {stage === 'waiting' && "Wait for Green..."}
        {stage === 'ready' && "CLICK NOW!"}
        {stage === 'result' && `Speed: ${Math.round(times[times.length - 1])}ms`}
      </div>
    </div>
  );
};

export default ReactionTest;
