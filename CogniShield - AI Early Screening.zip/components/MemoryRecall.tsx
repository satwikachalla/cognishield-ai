
import React, { useState } from 'react';

interface Props {
  onComplete: (words: string[]) => void;
}

const MemoryRecall: React.FC<Props> = ({ onComplete }) => {
  const [input, setInput] = useState("");
  const [words, setWords] = useState<string[]>([]);

  const handleAdd = () => {
    const trimmed = input.trim();
    if (trimmed && !words.includes(trimmed)) {
      setWords([...words, trimmed]);
      setInput("");
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleAdd();
  };

  return (
    <div className="max-w-xl mx-auto bg-white p-8 rounded-3xl shadow-sm border border-slate-100 space-y-8 animate-in zoom-in-95 duration-500">
      <div className="text-center space-y-2">
        <h2 className="text-2xl font-bold text-slate-800">Final Step: Recall</h2>
        <p className="text-slate-500">Type the 5 words you memorized at the start of the screening.</p>
      </div>

      <div className="flex gap-2">
        <input 
          autoFocus
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Type a word..."
          className="flex-1 p-4 rounded-xl border border-slate-200 focus:border-indigo-500 outline-none"
        />
        <button 
          onClick={handleAdd}
          className="bg-indigo-600 text-white px-6 rounded-xl font-bold hover:bg-indigo-700"
        >
          Add
        </button>
      </div>

      <div className="flex flex-wrap gap-2 justify-center">
        {words.map((w, i) => (
          <span key={i} className="px-4 py-2 bg-indigo-50 text-indigo-700 font-bold rounded-full border border-indigo-100 flex items-center gap-2">
            {w}
            <button onClick={() => setWords(words.filter(word => word !== w))} className="hover:text-red-500">×</button>
          </span>
        ))}
        {words.length === 0 && <p className="text-slate-300 italic">No words added yet.</p>}
      </div>

      <button 
        onClick={() => onComplete(words)}
        className="w-full py-4 bg-slate-900 text-white rounded-xl font-bold hover:bg-black transition-colors"
      >
        Finalize Screening
      </button>
    </div>
  );
};

export default MemoryRecall;
