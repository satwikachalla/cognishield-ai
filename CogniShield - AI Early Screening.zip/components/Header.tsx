
import React from 'react';

interface HeaderProps {
  onReset: () => void;
}

const Header: React.FC<HeaderProps> = ({ onReset }) => {
  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between max-w-6xl">
        <div 
          className="flex items-center gap-2 cursor-pointer group" 
          onClick={onReset}
        >
          <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white font-bold group-hover:scale-105 transition-transform">
            C
          </div>
          <h1 className="text-xl font-bold text-slate-800">CogniShield</h1>
        </div>
        <nav className="flex gap-4">
          <button 
            onClick={onReset}
            className="text-sm font-medium text-slate-500 hover:text-indigo-600 transition-colors"
          >
            New Screening
          </button>
          <span className="text-xs px-2 py-1 bg-indigo-50 text-indigo-700 rounded-full font-bold uppercase tracking-wider self-center">
            AI Screening MVP
          </span>
        </nav>
      </div>
    </header>
  );
};

export default Header;
